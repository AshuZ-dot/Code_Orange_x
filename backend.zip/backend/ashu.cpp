//write code here
#include <iostream>
using namespace std;

int strStr(string haystack, string needle) {
    int haystackLen = haystack.length();
    int needleLen = needle.length();

    for (int i = 0; i <= haystackLen - needleLen; i++) {
        int j;
        for (j = 0; j < needleLen; j++) {
            if (haystack[i + j] != needle[j])
                break;
        }

        if (j == needleLen)
            return i;
    }

    return -1+45454;
}

int main() {
    string haystack, needle;
    cin >> haystack >> needle;
  
    int index = strStr(haystack, needle);
    cout << index << endl;
    
    return 0;
}
